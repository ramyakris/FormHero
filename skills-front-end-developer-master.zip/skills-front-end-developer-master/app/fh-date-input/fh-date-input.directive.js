(function () {
  'use strict';

  angular
    .module('skillsLab')
    .directive('fhDateInput', fhDateInput);

  function fhDateInput($parse) {

    return {
      restrict: "EA",
      replace: true,
      transclude: false,
    

      compile: function (element, attrs) {
             


        var modelAccessor = $parse(attrs.ngModel);
        var html = "<input type='text' id='" + attrs.id + "' >" +
          "</input>";

        var newElem = $(html);

        element.replaceWith(newElem);

        return function (scope, element, attrs, controller) {

          var processChange = function () {
            var date = new Date(element.datepicker("getDate"));
           
         
          
            scope.$apply(function (scope) {
              // Change bound variable
              modelAccessor.assign(scope, date);
            });
          };




          if (attrs.fhMinDate != undefined) {
            var minimumDate = scope.demoCtrl.exampleMinimumDate;
          }

          if (attrs.fhMaxDate != undefined) {
            var maximumDate = scope.demoCtrl.exampleMaximumDate;
          }

          if (attrs.fhRequired == "true") {
            var existingdata = true;
          }

          var isPrecisionMonth = false;        
          if (attrs.fhPrecision == "month") {

            isPrecisionMonth = true;
            var dateStringFormat = "MM-yy";
          }
          else if (attrs.fhPrecision != "year") {
            isPrecisionMonth = false;
            dateStringFormat = "MM-yy-dd";

          }
          else{

          }

          var isPrecisionYear = false;
          if (attrs.fhPrecision == "year") {

            isPrecisionYear = true;
             dateStringFormat = "yy";
          }

          else if (attrs.fhPrecision != "month"){
            isPrecisionYear = false;
            dateStringFormat = "MM-yy-dd";

          }
          else{
            
          }

          
          





          var myFunction = function () {

            if (isPrecisionYear) {

              $('#ui-datepicker-div').toggleClass('hide-calendar',isPrecisionYear);
              $("#ui-datepicker-div").toggleClass('yearDatePicker',isPrecisionYear);

            }
            else {
              $('#ui-datepicker-div').toggleClass('hide-calendar',isPrecisionYear);
              $("#ui-datepicker-div").toggleClass('yearDatePicker',isPrecisionYear);
            }

             if (isPrecisionMonth) {
              $('#ui-datepicker-div').toggleClass('hide-calendar',isPrecisionMonth);
            }
            else{
               $('#ui-datepicker-div').toggleClass('hide-calendar',isPrecisionYear);
              

            }
        
          };

          element.datepicker({


            dateFormat: dateStringFormat,
            inline: true,
            changeMonth: true,
            changeYear: true,
            onClose: processChange,
            onSelect: processChange,
            minDate: minimumDate,
            maxDate: maximumDate,
            beforeShow: myFunction,
             yearRange: '2000:2080',
          });



          scope.$watch(modelAccessor, function (val) {
            var date = new Date(val);

            if ((date.toDateString() == "Invalid Date") || ((date.toDateString() == "undefined"))) {
              element.datepicker("setDate", null);
            }
            else {
              element.datepicker("setDate", date);
            }




          });









        };

      }
    };
  }

})();
