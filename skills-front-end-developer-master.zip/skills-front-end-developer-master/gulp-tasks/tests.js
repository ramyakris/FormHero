module.exports = function(gulp, plugins, buildProperties) {

    gulp.task('run-tests', ['build'], function() {

    });

};